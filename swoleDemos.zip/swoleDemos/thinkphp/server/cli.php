<?php
/**
 * Created by PhpStorm.
 * User: niuyueyang
 * Date: 2019/4/17
 * Time: 20:51
 */
//9601端口向9599发送信息，server应该是9599，也就是两个交叉发送
ini_set('default_socket_timeout', -1);
$redis = new Redis();
$redis->connect('127.0.0.1',6379);

$redis->subscribe(['chat'], function ($redisMs, $chan, $msg) {
    $code=json_decode($msg,true)['code'];
    print_r($code);
    if($code==9601){
        curl_post('http://127.0.0.1:9599/?s=admin/live/sendOther',json_decode($msg,true));
        echo '9601端口向9599端口发送信息成功';
    }
});

function curl_post($url, $postdata)
{
    print_r($postdata);
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    return $result;
}