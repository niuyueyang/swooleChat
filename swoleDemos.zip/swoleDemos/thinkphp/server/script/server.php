<?php
/**
 * Created by PhpStorm.
 * User: niuyueyang
 * Date: 2019/4/11
 * Time: 13:24
 */
//nohup /usr/bin/php /php/tp/thinkphp/server/script/server.php >  /php/tp/thinkphp/server/script/server.txt
class Server{
    const PORT=9601;
    public function port(){
        $shell="netstat -anp 2>/dev/null | grep ".self::PORT.'| grep LISTEN | wc -l';
        $result=shell_exec($shell);
        if($result!=1){
            //异常报警
            echo date("Ymd H:i:s")."error".PHP_EOL;
        }
        else{
            echo date("Ymd H:i:s")."success".PHP_EOL;
        }
    }
}
swoole_timer_tick(2000,function ($timer_id){
    (new Server())->port();
});