<?php
/**
 * Created by PhpStorm.
 * User: niuyueyang
 * Date: 2019/4/17
 * Time: 21:19
 */
$redis = new Redis();
$redis->connect('127.0.0.1',6379);
$res = $redis->publish('chat','hhh');
echo 'clents'.$res;