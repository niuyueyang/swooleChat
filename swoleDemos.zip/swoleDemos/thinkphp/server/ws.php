<?php
/**
 * Created by PhpStorm.
 * User: niuyueyang
 * Date: 2019/3/8
 * Time: 15:13
 */
require __DIR__."/../../application/common/task/Task.php";
class Ws{
    const HOST='0.0.0.0';
    const PORT=9601;
    public $ws=null;
    public function __construct()
    {
        //如果重启，在这里把redis所有personId的值清空
        $this->ws=new swoole_websocket_server(self::HOST,self::PORT);
//        $this->ws->listen(self::HOST,self::CHART_PORT,SWOOLE_SOCK_TCP);
        $this->ws->set(
            [
                'enable_static_handler' => true,
                'document_root' => '/php/tps/public',
                'worker_num' => 5,
                'task_worker_num'=>2
            ]
        );
        $this->ws->on('request',[$this,'onRequest']);
        $this->ws->on('workerstart',[$this,'onWorkerStart']);
        $this->ws->on('open',[$this,'onOpen']);
        $this->ws->on('message',[$this,'onMessage']);
        $this->ws->on('task',[$this,'onTask']);
        $this->ws->on('finish',[$this,'onFinish']);
        $this->ws->on('close',[$this,'onClose']);
        $this->ws->start();
    }
    public function onWorkerStart($server,$worker_id){
        define('APP_PATH', __DIR__ . '/../../application/');
        // 加载基础文件
        require __DIR__ . '/../base.php';
    }

    public function onRequest($request,$response){
        $response->header('Access-Control-Allow-Origin','*');
        $_SERVER = [];
        if (isset($request->server)) {
            foreach ($request->server as $key => $value) {
                $_SERVER[strtoupper($key)] = $value;
            }
        }

        if (isset($request->header)) {
            foreach ($request->header as $key => $value) {
                $_SERVER[strtoupper($key)] = $value;
            }
        }

        // swoole对于超全局数组：$_SERVER、$_GET、$_POST、define不会释放
        $_GET = [];
        if (isset($request->get)) {
            foreach ($request->get as $key => $value) {
                $_GET[$key] = $value;
            }
        }
        $_FILES = [];
        if (isset($request->files)) {
            foreach ($request->files as $key => $value) {
                $_FILES[$key] = $value;
            }
        }
        $_POST = [];
        if (isset($request->post)) {
            foreach ($request->post as $key => $value) {
                $_POST[$key] = $value;
            }
        }
        $_POST['swooleData']=$_POST;
        $this->writeLog();
        $_POST['http_server']=$this->ws; //注意顺序

//        print_r($this->ws->connections);
        // ob函数输出打印
        ob_start();
        try {
            think\Container::get('app', [APP_PATH]) ->run() ->send();
        } catch (\Exception $e) {
            // todo
        }
        $res = ob_get_contents();
        ob_end_clean();
        $response->end($res);
        //$this->http->close($request->fd);
    }

    public function onOpen($ws,$request){
        $port = 6379;
        $redis = new \Redis();
        $redis->connect('127.0.0.1',$port, 300);
        $redis->sAdd('personId_9601',$request->fd);
        $redis->set('server9601_'.$request->fd,'http://39.106.10.163:9601');
        var_dump($request->fd);
}

    public function onMessage($ws,$frame){
        var_dump($frame);
        $content = $frame->data;
        echo "服务器接收到信息：".json_encode($content);
//        // 2.讲消息发送个所有客户端
//        foreach ($ws->connections as $fd){
//            $ws->push($fd,$content);
//        }
        //$ws->push($frame->fd,date('Y-m-d H:i:s'));
    }

    //$data为send.php $_POST['http_server']->task($taskData)传递过来的
    public function onTask($serv,$taskId,$workerId,$data){
        //分发task任务机制
        $obj=new \Task();
        $method=$data['method'];
        $flag=$obj->$method($data['data']);
        return $flag;
//        return 'task finish';
    }
    public function onFinish($serv,$taskId,$data){
        echo "taskId：{$taskId}\n";
        echo "finish-data-success：{$data}\n";

    }
    public function onClose($ws,$fd){
        $port = 6379;
        $redis = new \Redis();
        $redis->connect('127.0.0.1',$port, 300);
        $redis->sRem('personId_9601',$fd);
	    $redis->del('server9601_'.$fd);
        echo "{$fd} leave\n";
    }
    //日志书写
    public function writeLog(){
       $datas=$_GET;
       $logs="【".date('Y-m-d H:i:s')."】".PHP_EOL;
       foreach ($_GET as $key => $val){
           $logs .=$key . ":" . $val . " ".PHP_EOL;
       }
       foreach ($_POST['swooleData'] as $key => $val){
           $logs .=$key . ":" . $val . " ".PHP_EOL;
       }
        foreach ($_SERVER as $key => $val){
            $logs .=$key . ":" . $val . " ".PHP_EOL;
        }
//       swoole_async_writefile(APP_PATH."/../runtime/log/".date('Ym')."/".date('d')."_access.log",$logs.PHP_EOL,function ($filename){
//
//       },FILE_APPEND);
        $myfile = fopen(APP_PATH."/../runtime/log/".date('Ym')."/".date('d')."_access.log", "a") or die("Unable to open file!");
        $txt = $logs;
        fwrite($myfile, $txt);
        fclose($myfile);
//        $txt = "Steve Jobs\n";
//        fwrite($myfile, $txt);
//        fclose($myfile);
    }
}
new Ws();