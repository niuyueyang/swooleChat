<?php
/**
 * Created by PhpStorm.
 * User: niuyueyang
 * Date: 2019/3/5
 * Time: 19:42
 */
return [
    'host'=>'127.0.0.1',
    'port'=>6379,
    'out_time'=>300
];