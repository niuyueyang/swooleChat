var wsUrl='ws://39.106.10.163:9600';
var websocket=new WebSocket(wsUrl);
websocket.onopen=function (evt) {
    console.log('connected success');
}
websocket.onmessage=function (evt) {
    console.log(evt.data);
    var data=JSON.parse(evt.data);
    if(data.mType=='chat'){
        var html='<div class="comment">\n' +
            '<span>'+data.user+'</span>\n' +
            '<span>'+data.content+'</span>\n' +
            '</div>';
        $("#comments").append(html);
    }
}
websocket.onclose=function (evt) {
    console.log('close');
}
websocket.onerror=function (evt,e) {
    console.log(evt.data);
}
function pushs(data){
    if(data.mType=='chat'){
        var html='<div class="comment">\n' +
            '<span>'+data.user+'</span>\n' +
            '<span>'+data.content+'</span>\n' +
            '</div>';
        $("#comments").append(html);
    }
}