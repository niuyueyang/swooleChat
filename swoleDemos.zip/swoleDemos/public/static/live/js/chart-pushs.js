$(function () {
    $("#disuss-box").keydown(function (event) {
        if(event.keyCode==13){
            var text=$(this).val();
            var data={'content':text,'game_id':1};
            $.ajax({
                url:'http://39.106.10.163:9600/?s=index/chart/indexs',
                data:data,
                method:'post',
                success:function (data) {
                    console.log(data)
                },
                error:function (err) {
                    console.log(err)
                }
            })
        }
    })
})