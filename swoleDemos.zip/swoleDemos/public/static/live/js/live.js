var wsUrl='ws://39.106.10.163:9601';
var websocket=new WebSocket(wsUrl);
websocket.onopen=function (evt) {
    console.log('connected success');
}
websocket.onmessage=function (evt) {
    // push(JSON.parse(evt.data));
    console.log(evt.data);
    $("#first").remove();
    var data=JSON.parse(evt.data);
    if(data.mType=='live'){
        var html='<div class="frame">\n' +
            '<h3 class="frame-header">\n' +
            '<i class="icon iconfont icon-shijian"></i>第'+data.type+'节 '+data.time+'\n' +
            '</h3>\n' +
            '<div class="frame-item">\n' +
            '<span class="frame-dot"></span>\n' +
            '<div class="frame-item-author">\n' +
            '<img src="'+data.logo+'" width="20px" height="20px"> '+data.title+'\n' +
            '</div>\n' +
            '<p>'+data.content+'</p>\n' +
            '</div>\n' +
            '</div>';
        $("#match-result").append(html);
    }
   if(data.mType=='chat'){
       console.log(9601)
        $("#second").remove();
        var html='<div class="comment">\n' +
            '<span>'+data.user+'</span>\n' +
            '<span>'+data.content+'</span>\n' +
            '</div>';
        $("#comments").append(html);
    }
}
websocket.onclose=function (evt) {
    console.log('close');
}
websocket.onerror=function (evt,e) {
    console.log(evt.data);
}
// function push(data){
//     var html='<div class="frame">\n' +
//         '<h3 class="frame-header">\n' +
//         '<i class="icon iconfont icon-shijian"></i>第'+data.type+'节 '+data.time+'\n' +
//         '</h3>\n' +
//         '<div class="frame-item">\n' +
//         '<span class="frame-dot"></span>\n' +
//         '<div class="frame-item-author">\n' +
//         '<img src="'+data.logo+'" width="20px" height="20px"> '+data.title+'\n' +
//         '</div>\n' +
//         '<p>'+data.content+'</p>\n' +
//         '</div>\n' +
//         '</div>';
//     console.log(html)
//     $("#match-result").append(html);
// }